<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'u190393894_and');
define('DB_PASSWORD', 'tranthanhphong1989');
define('DB_HOST', 'mysql.hostinger.vn');
define('DB_NAME', 'u190393894_and');


define('USER_CREATED_SUCCESSFULLY', 0);
define('USER_CREATE_FAILED', 1);
define('USER_ALREADY_EXISTED', 2);
?>
